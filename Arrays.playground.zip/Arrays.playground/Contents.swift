import Cocoa
import Foundation

//*Objective Creating an array
//var bucketList: Array<String>

//*Objective Changing the syntax - with [] instead of writing the word and <>
//var bucketList: [String]

//*Objective initializing the array
//bucketList = ["Run a business", "Transition into an iOS Developer", "Create a profittable mobile application"]

//*Objective initializing the array alongside its declaration
//var bucketList: [String] = ["Run a business", "Transition into an iOS Developer", "Create a profittable mobile application"]

//*Objective Using type inference
var bucketList = ["Transition into an iOS Developer"]


//Access and modifying Arrays
//*Objective reading the classics
bucketList.append ("Create a world class application")

//*Objective adding more arrays
bucketList.append ("Learn more about investing, web 3.0, and crypto")
bucketList.append ("Learn how to mangage stress")
bucketList.append ("Own a home")

//* Objective counting items in an array
bucketList.count

//* Objective - removing an item from am array
bucketList.remove(at: 3)
bucketList

//*Objective - subscripting to find your top three items
print(bucketList[...2])

//*Objective - subscripting to append new information
bucketList[1] += " to build up my portfolio"
bucketList[1]

//*Objective - replacing an array item
bucketList[0] = "Transition into a full-stack developer"
bucketList

//*Objective - inserting a new array item
bucketList.insert("Learn how to code in Swift, JavaScript, Kotlin & Java", at: 1)
bucketList

//*Objective - Using a loop to append items from one array to another
var newItems = [
    "Own a truck",
    "Save 6 month's of expenses",
    "Help my family"
]

/*for item in newItems {
    bucketList.append(item)
}
print(bucketList)*/

//*Objective - refactoring with the addition and assignment operator
bucketList += newItems
print(bucketList)

//*Objective - Checking two arrays for equality
var anotherList = [
"Own a truck",
"Save 6 month's of expenses",
"Help my family"
]
newItems == anotherList

//*Objective - An Immutable Array
let lunches = [
"Cheeseburger",
"Veggie Pizza",
"Black Bean Burrito",
"Falafel Wrap"
]

//bronze challenge
var toDoList = ["Take out the trash", "Pay Bills", "Cross off finished items"]
toDoList.isEmpty

//Silver challenge
toDoList.reverse()
print(toDoList)
var randomToDoList = toDoList.shuffled()
print(randomToDoList)

